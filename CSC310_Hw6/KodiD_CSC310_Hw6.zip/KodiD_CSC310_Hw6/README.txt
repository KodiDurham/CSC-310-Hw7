CSC 310 Data Structures
Homework 6 

CSC310_HW6_1
	This program when started will give the user a menu which is easy to follow to. It will allow the user to run demo, add objects to the queue, get the min of the queue, remove the min, and get the size of the queue.
ex:
run:
1. Run Demo
2. Add to queue
3. Get Min
4. Remove Min
5. Get size
e. Exit
Pick an option from the menu above:1
Sequence: 7 => 4 => 8 => 2 => 5 => 3 => 9

Priority: 2 => 3 => 4 => 5 => 7 => 8 => 9



CSC310_Hw6_2
	This program when started will give the user a menu which is easy to follow to. It will allow the user to run demo, make a heap, remove the max of the heap, and remove all the contents of the heap.
ex:
1. Run Demo
2. Make heap
3. remove max
4. Empty heap
e. Exit
Pick an option from the menu above:1
Sequence: 9 => 7 => 5 => 2 => 6 => 4

Max Order: 9 => 7 => 6 => 5 => 4 => 2

1. Run Demo
2. Make heap
3. remove max
4. Empty heap
e. Exit
Pick an option from the menu above:


CSC310_Hw6_3
	When this program starts it will run through an exapmle of all the functions and will end on it's own after it is done. 
ex:output:
3
5
7
11

IsEmpty: true
IsEmpty: false

Find min: 3
Delete min: 3
Find min: 5

Size: 3
Delete min: 5
Size: 2

1
2
4
6
7
10
11

0
1
3
5
6
9
11
